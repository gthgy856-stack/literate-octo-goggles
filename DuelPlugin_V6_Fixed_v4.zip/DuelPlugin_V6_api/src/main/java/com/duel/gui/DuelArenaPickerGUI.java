package com.duel.gui;

import com.duel.DuelPlugin;
import com.duel.models.Arena;
import com.duel.utils.ItemUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class DuelArenaPickerGUI implements InventoryHolder {

    public static final Map<UUID, UUID> PICKER_TARGETS = new ConcurrentHashMap<>();

    private final DuelPlugin plugin;
    private final Inventory  inventory;
    private final Player     target;

    public DuelArenaPickerGUI(DuelPlugin plugin, Player target) {
        this.plugin = plugin;
        this.target = target;
        this.inventory = Bukkit.createInventory(this, 54,
                Component.text("⚔  Challenge: ")
                        .color(NamedTextColor.GOLD)
                        .decoration(TextDecoration.BOLD, true)
                        .append(Component.text(target.getName())
                                .color(NamedTextColor.YELLOW)
                                .decoration(TextDecoration.BOLD, false))
                        .append(Component.text("  —  Select Arena")
                                .color(NamedTextColor.GRAY)
                                .decoration(TextDecoration.BOLD, false)));
        populate();
    }

    private void populate() {
        ItemStack border = ItemUtils.buildFiller(Material.ORANGE_STAINED_GLASS_PANE);
        for (int i = 0; i < 9; i++)    inventory.setItem(i, border);
        for (int i = 45; i < 54; i++)  inventory.setItem(i, border);
        for (int i = 9; i < 45; i += 9)  inventory.setItem(i, border);
        for (int i = 17; i < 45; i += 9) inventory.setItem(i, border);

        inventory.setItem(4, buildTargetInfoItem());

        Collection<Arena> arenas = plugin.getArenaManager().getAllArenas();
        int[] slots = getInteriorSlots();
        int idx = 0;

        for (Arena arena : arenas) {
            if (idx >= slots.length) break;
            List<ItemStack> items = arena.getGuiItems();
            if (items.isEmpty()) { idx++; continue; }

            ItemStack display = items.get(0).clone();
            ItemMeta meta = display.getItemMeta();

            meta.displayName(Component.text("⚔  " + arena.getId())
                    .color(NamedTextColor.AQUA)
                    .decoration(TextDecoration.BOLD, true)
                    .decoration(TextDecoration.ITALIC, false));

            List<Component> lore = new ArrayList<>();
            lore.add(Component.empty());
            lore.add(Component.text("In Queue: ").color(NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false)
                    .append(Component.text(plugin.getQueueManager().getQueueSize(arena) + " player(s)")
                            .color(NamedTextColor.YELLOW)
                            .decoration(TextDecoration.ITALIC, false)));
            lore.add(Component.text("Active: ").color(NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false)
                    .append(Component.text(plugin.getDuelManager().getActiveCountForArena(arena.getId()) + " duel(s)")
                            .color(NamedTextColor.GREEN)
                            .decoration(TextDecoration.ITALIC, false)));
            lore.add(Component.empty());
            lore.add(Component.text("▶  Click to challenge " + target.getName())
                    .color(NamedTextColor.GOLD)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(lore);
            display.setItemMeta(meta);
            inventory.setItem(slots[idx], display);
            idx++;
        }

        if (arenas.isEmpty()) {
            inventory.setItem(22, ItemUtils.build(Material.BARRIER, "No Arenas Available",
                    NamedTextColor.RED, "Ask an admin to configure arenas."));
        }
    }

    private ItemStack buildTargetInfoItem() {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        org.bukkit.inventory.meta.SkullMeta meta = (org.bukkit.inventory.meta.SkullMeta) item.getItemMeta();
        meta.setOwningPlayer(org.bukkit.Bukkit.getOfflinePlayer(target.getUniqueId()));

        int ping = target.getPing();
        NamedTextColor pingColor = ping < 80 ? NamedTextColor.GREEN : ping < 150 ? NamedTextColor.YELLOW : NamedTextColor.RED;

        meta.displayName(Component.text("🎯  Challenging: " + target.getName())
                .color(NamedTextColor.GOLD)
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        lore.add(Component.text("Player: ").color(NamedTextColor.GRAY)
                .append(Component.text(target.getName()).color(NamedTextColor.WHITE)));
        lore.add(Component.text("Ping: ").color(NamedTextColor.GRAY)
                .append(Component.text(ping + " ms").color(pingColor)));
        lore.add(Component.empty());
        lore.add(Component.text("Select an arena below").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, true));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public static int[] getInteriorSlots() {
        List<Integer> slots = new ArrayList<>();
        for (int row = 1; row <= 4; row++)
            for (int col = 1; col <= 7; col++) {
                int s = row * 9 + col;
                if (s == 4) continue;
                slots.add(s);
            }
        return slots.stream().mapToInt(Integer::intValue).toArray();
    }

    public static void open(DuelPlugin plugin, Player sender, Player target) {
        DuelArenaPickerGUI gui = new DuelArenaPickerGUI(plugin, target);
        PICKER_TARGETS.put(sender.getUniqueId(), target.getUniqueId());
        sender.openInventory(gui.getInventory());
    }

    public Player getTarget() { return target; }

    @Override
    public Inventory getInventory() { return inventory; }
}
